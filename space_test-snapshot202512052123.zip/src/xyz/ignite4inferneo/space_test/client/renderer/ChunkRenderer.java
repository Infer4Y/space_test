package xyz.ignite4inferneo.space_test.client.renderer;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.*;
import java.util.List;

/**
 * ChunkRenderer with MVP pipeline, camera controls, greedy meshing, and frustum culling
 */
public class ChunkRenderer {
    private static final boolean USE_TRANSPARENCY = true;
    private static final int CHUNK_SIZE = 16;
    private final Cube[][][] blocks = new Cube[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE];

    private Dimension canvasSize;
    private BufferedImage screenBuffer;
    private BufferedImage smallBuffer;
    private int[] smallPixels;
    private float[] zBufInv;
    private int smallW, smallH;
    private final int pixelScale;

    // Virtual resolution - projection target
    private int virtualW, virtualH;

    private final List<Quad> mesh = new ArrayList<>();
    private boolean dirty = true;

    private long lastTime;
    private double angle = 0;
    private final Random rand = new Random();

    private final BufferedImage[] globalFaceTextures = new BufferedImage[6];

    // Projection parameters
    private final double fovDeg = 60.0;
    private final double zNear = 0.1;
    private final double zFar = 1000.0;

    // Camera position and rotation
    private double cameraX = 0, cameraY = 0, cameraZ = 0;
    private double cameraYaw = 0, cameraPitch = Math.toRadians(30);

    // Greedy meshing toggle
    private boolean useGreedyMeshing = false;

    public ChunkRenderer(int pixelScale) {
        this.pixelScale = Math.max(1, pixelScale);
        this.lastTime = System.nanoTime();

        // Generate terrain with layers
        for (int x = 0; x < CHUNK_SIZE; x++)
            for (int y = 0; y < CHUNK_SIZE; y++)
                for (int z = 0; z < CHUNK_SIZE; z++) {
                    float r = rand.nextFloat();
                    if (y < 6 && r < 0.6f) {
                        blocks[x][y][z] = new Cube();
                    } else if (y >= 6 && y < 10 && r < 0.4f) {
                        blocks[x][y][z] = new Cube();
                    } else if (y >= 10 && r < 0.2f) {
                        blocks[x][y][z] = new Cube();
                    } else {
                        blocks[x][y][z] = null;
                    }
                }

        // Create textures for each face
        globalFaceTextures[0] = TextureUtils.createBlockTexture("grass", 64);
        globalFaceTextures[1] = TextureUtils.createBlockTexture("grass", 64);
        globalFaceTextures[2] = TextureUtils.createBlockTexture("dirt", 64);
        globalFaceTextures[3] = TextureUtils.createBlockTexture("grass", 64);
        globalFaceTextures[4] = TextureUtils.createBlockTexture("grass", 64);
        globalFaceTextures[5] = TextureUtils.createBlockTexture("grass", 64);

        dirty = true;
    }

    public ChunkRenderer() { this(1); }

    public void setCanvasSize(Dimension size) {
        canvasSize = size;
        if (size == null) return;
        screenBuffer = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);

        virtualW = size.width;
        virtualH = size.height;

        smallW = Math.max(1, size.width / pixelScale);
        smallH = Math.max(1, size.height / pixelScale);
        smallBuffer = new BufferedImage(smallW, smallH, BufferedImage.TYPE_INT_ARGB);
        smallPixels = ((DataBufferInt) smallBuffer.getRaster().getDataBuffer()).getData();
        zBufInv = new float[smallW * smallH];

        dirty = true;
    }

    public BufferedImage getScreenBuffer() { return screenBuffer; }
    public void setAngle(double angle) { this.angle = angle; }
    public void markDirty() { dirty = true; }

    // ========== CAMERA CONTROL METHODS ==========

    public void moveCamera(double forward, double right, double up) {
        // Move relative to camera orientation (yaw only, not pitch)
        double cos = Math.cos(cameraYaw);
        double sin = Math.sin(cameraYaw);

        // Forward/back and left/right relative to yaw
        cameraX += forward * sin + right * cos;
        cameraZ += forward * cos - right * sin;

        // Up/down is always absolute (not affected by camera rotation)
        cameraY += up;
    }

    public void rotateCamera(double yaw, double pitch) {
        cameraYaw += yaw;
        cameraPitch = Math.max(-Math.PI/2 + 0.01, Math.min(Math.PI/2 - 0.01, cameraPitch + pitch));
    }

    public void setCameraPosition(double x, double y, double z) {
        cameraX = x;
        cameraY = y;
        cameraZ = z;
    }

    public void setGreedyMeshing(boolean enabled) {
        if (useGreedyMeshing != enabled) {
            useGreedyMeshing = enabled;
            dirty = true;
        }
    }

    public boolean isUsingGreedyMeshing() {
        return useGreedyMeshing;
    }

    // ========== RENDERING ==========

    public void render() {
        if (canvasSize == null || screenBuffer == null) return;

        long now = System.nanoTime();
        double delta = (now - lastTime) / 1_000_000_000.0;
        lastTime = now;
        angle += delta * Math.PI / 8.0;

        buildMeshIfNeeded();

        Arrays.fill(smallPixels, 0xFF000000);
        Arrays.fill(zBufInv, Float.MAX_VALUE);

        double aspect = (double) virtualW / (double) virtualH;
        double[][] projMat = perspectiveMatrix(Math.toRadians(fovDeg), aspect, zNear, zFar);
        double[][] viewMat = viewMatrix(cameraX, cameraY, cameraZ, cameraYaw, cameraPitch);
        double[][] modelMat = rotationYMatrix(angle);
        double[][] vp = multiplyMatrices(projMat, viewMat);
        double[][] mvp = multiplyMatrices(vp, modelMat);
        double[][] vm = multiplyMatrices(viewMat, modelMat);

        List<QuadInstance> transparentQuads = USE_TRANSPARENCY ? new ArrayList<>() : null;

        for (Quad q : mesh) {
            double[][] proj = q.projected;
            if (proj == null) { q.projected = new double[4][3]; proj = q.projected; }

            // Simple backface culling and projection
            boolean anyVisible = false;

            for (int i = 0; i < 4; i++) {
                double[] v = new double[]{ q.verts[i][0], q.verts[i][1], q.verts[i][2], 1.0 };
                double[] clip = transformVec4(mvp, v);
                double w = clip[3];
                if (Math.abs(w) < 1e-6) w = 1e-6;

                double ndcX = clip[0] / w;
                double ndcY = clip[1] / w;
                double ndcZ = clip[2] / w;

                // Check if this vertex is visible
                if (ndcX >= -1.5 && ndcX <= 1.5 && ndcY >= -1.5 && ndcY <= 1.5 && ndcZ >= -1 && ndcZ <= 1) {
                    anyVisible = true;
                }

                double sx = (ndcX * 0.5 + 0.5) * virtualW;
                double sy = (1.0 - (ndcY * 0.5 + 0.5)) * virtualH;

                double[] mv = transformVec4(vm, v);
                double viewZ = mv[2];

                proj[i][0] = sx;
                proj[i][1] = sy;
                proj[i][2] = viewZ;
            }

            // Skip if completely off screen
            if (!anyVisible) continue;

            if (q.isTransparent) {
                if (USE_TRANSPARENCY) {
                    double depth = (proj[0][2] + proj[1][2] + proj[2][2] + proj[3][2]) * 0.25;
                    transparentQuads.add(new QuadInstance(q, proj, depth));
                }
            } else {
                drawQuadPolygonTextured(proj, q);
            }
        }

        if (USE_TRANSPARENCY && !transparentQuads.isEmpty()) {
            transparentQuads.sort((a, b) -> Double.compare(b.depth, a.depth));
            for (QuadInstance qi : transparentQuads)
                drawQuadPolygonTextured(qi.projected, qi.quad);
        }

        // Upscale
        int screenW = screenBuffer.getWidth();
        int screenH = screenBuffer.getHeight();
        int[] bigPixels = ((DataBufferInt) screenBuffer.getRaster().getDataBuffer()).getData();
        for (int sy = 0; sy < screenH; sy++) {
            int smallY = Math.min(smallH - 1, sy / pixelScale);
            int rowSmall = smallY * smallW;
            int rowBig = sy * screenW;
            for (int sx = 0; sx < screenW; sx++) {
                int smallX = Math.min(smallW - 1, sx / pixelScale);
                bigPixels[rowBig + sx] = smallPixels[rowSmall + smallX];
            }
        }
    }

    // ========== MESH BUILDING ==========

    private void buildMeshIfNeeded() {
        if (!dirty) return;
        mesh.clear();

        if (useGreedyMeshing) {
            System.out.println("Building greedy mesh...");
            buildGreedyMesh();
        } else {
            System.out.println("Building simple mesh...");
            buildSimpleMesh();
        }

        System.out.println("Mesh built: " + mesh.size() + " quads");
        dirty = false;
    }

    private void buildSimpleMesh() {
        for (int x = 0; x < CHUNK_SIZE; x++) {
            for (int y = 0; y < CHUNK_SIZE; y++) {
                for (int z = 0; z < CHUNK_SIZE; z++) {
                    if (blocks[x][y][z] == null) continue;

                    if (!inBounds(x-1, y, z) || blocks[x-1][y][z] == null) addQuad(x, y, z, 0, 5);
                    if (!inBounds(x+1, y, z) || blocks[x+1][y][z] == null) addQuad(x, y, z, 1, 4);
                    if (!inBounds(x, y-1, z) || blocks[x][y-1][z] == null) addQuad(x, y, z, 2, 2);
                    if (!inBounds(x, y+1, z) || blocks[x][y+1][z] == null) addQuad(x, y, z, 3, 3);
                    if (!inBounds(x, y, z-1) || blocks[x][y][z-1] == null) addQuad(x, y, z, 4, 0);
                    if (!inBounds(x, y, z+1) || blocks[x][y][z+1] == null) addQuad(x, y, z, 5, 1);
                }
            }
        }
    }

    private void buildGreedyMesh() {
        greedyAxis(0);
        greedyAxis(1);
        greedyAxis(2);
    }

    private void addQuad(int x, int y, int z, int side, int faceIndex) {
        double[][] verts = new double[4][3];

        switch(side) {
            case 0: // -X
                verts[0] = new double[]{x, y, z};
                verts[1] = new double[]{x, y, z+1};
                verts[2] = new double[]{x, y+1, z+1};
                verts[3] = new double[]{x, y+1, z};
                break;
            case 1: // +X
                verts[0] = new double[]{x+1, y, z};
                verts[1] = new double[]{x+1, y+1, z};
                verts[2] = new double[]{x+1, y+1, z+1};
                verts[3] = new double[]{x+1, y, z+1};
                break;
            case 2: // -Y
                verts[0] = new double[]{x, y, z};
                verts[1] = new double[]{x+1, y, z};
                verts[2] = new double[]{x+1, y, z+1};
                verts[3] = new double[]{x, y, z+1};
                break;
            case 3: // +Y
                verts[0] = new double[]{x, y+1, z};
                verts[1] = new double[]{x, y+1, z+1};
                verts[2] = new double[]{x+1, y+1, z+1};
                verts[3] = new double[]{x+1, y+1, z};
                break;
            case 4: // -Z
                verts[0] = new double[]{x, y, z};
                verts[1] = new double[]{x, y+1, z};
                verts[2] = new double[]{x+1, y+1, z};
                verts[3] = new double[]{x+1, y, z};
                break;
            case 5: // +Z
                verts[0] = new double[]{x, y, z+1};
                verts[1] = new double[]{x+1, y, z+1};
                verts[2] = new double[]{x+1, y+1, z+1};
                verts[3] = new double[]{x, y+1, z+1};
                break;
            default:
                return;
        }

        double half = CHUNK_SIZE / 2.0;
        for (int i = 0; i < 4; i++) {
            verts[i][0] -= half;
            verts[i][1] -= half;
            verts[i][2] -= half;
        }

        double[][] uvs = new double[][]{{0, 0}, {1, 0}, {1, 1}, {0, 1}};
        BufferedImage tex = globalFaceTextures[faceIndex];
        int[] texPixels = ((DataBufferInt) tex.getRaster().getDataBuffer()).getData();

        Quad quad = new Quad(verts, uvs, texPixels, tex.getWidth(), tex.getHeight(), faceIndex, false);
        mesh.add(quad);
    }

    private void greedyAxis(int axis) {
        int u = (axis + 1) % 3;
        int v = (axis + 2) % 3;
        int[] dims = {CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE};

        for (int d = 0; d < dims[axis]; d++) {
            FaceInfo[][] mask = new FaceInfo[dims[u]][dims[v]];
            for (int i = 0; i < dims[u]; i++) {
                for (int j = 0; j < dims[v]; j++) {
                    int x = axis == 0 ? d : (u == 0 ? i : j);
                    int y = axis == 1 ? d : (u == 1 ? i : j);
                    int z = axis == 2 ? d : (u == 2 ? i : j);
                    int nx = axis == 0 ? d + 1 : x;
                    int ny = axis == 1 ? d + 1 : y;
                    int nz = axis == 2 ? d + 1 : z;
                    Cube a = inBounds(x, y, z) ? blocks[x][y][z] : null;
                    Cube b = inBounds(nx, ny, nz) ? blocks[nx][ny][nz] : null;

                    if (a != null && b == null) mask[i][j] = new FaceInfo(faceIndexForAxis(axis, true), globalFaceTextures[faceIndexForAxis(axis, true)], false);
                    else if (a == null && b != null) mask[i][j] = new FaceInfo(faceIndexForAxis(axis, false), globalFaceTextures[faceIndexForAxis(axis, false)], false);
                    else mask[i][j] = null;
                }
            }

            boolean[][] used = new boolean[dims[u]][dims[v]];
            for (int i = 0; i < dims[u]; i++) {
                for (int j = 0; j < dims[v]; j++) {
                    if (used[i][j]) continue;
                    FaceInfo fi = mask[i][j];
                    if (fi == null) continue;

                    int w = 1;
                    while (i + w < dims[u] && !used[i + w][j] && sameFaceInfo(fi, mask[i + w][j])) w++;
                    int h = 1;
                    outer:
                    while (j + h < dims[v]) {
                        for (int k = 0; k < w; k++)
                            if (used[i + k][j + h] || !sameFaceInfo(fi, mask[i + k][j + h])) break outer;
                        h++;
                    }

                    for (int a0 = 0; a0 < w; a0++)
                        for (int b0 = 0; b0 < h; b0++)
                            used[i + a0][j + b0] = true;

                    addGreedyQuad(axis, d, i, j, w, h, fi);
                }
            }
        }
    }

    private void addGreedyQuad(int axis, int d, int i, int j, int w, int h, FaceInfo fi) {
        double x0 = 0, y0 = 0, z0 = 0;
        if (axis == 0) { x0 = d; y0 = i; z0 = j; }
        else if (axis == 1) { x0 = i; y0 = d; z0 = j; }
        else { x0 = i; y0 = j; z0 = d; }

        double du = w, dv = h;
        boolean positive = fi.faceIndex == faceIndexForAxis(axis, true);

        double[][] verts = new double[4][3];
        if (axis == 0) {
            if (positive) {
                verts[0] = new double[]{d + 1, y0, z0};
                verts[1] = new double[]{d + 1, y0 + du, z0};
                verts[2] = new double[]{d + 1, y0 + du, z0 + dv};
                verts[3] = new double[]{d + 1, y0, z0 + dv};
            } else {
                verts[0] = new double[]{d, y0, z0};
                verts[1] = new double[]{d, y0, z0 + dv};
                verts[2] = new double[]{d, y0 + du, z0 + dv};
                verts[3] = new double[]{d, y0 + du, z0};
            }
        } else if (axis == 1) {
            if (positive) {
                verts[0] = new double[]{x0, d + 1, z0};
                verts[1] = new double[]{x0 + du, d + 1, z0};
                verts[2] = new double[]{x0 + du, d + 1, z0 + dv};
                verts[3] = new double[]{x0, d + 1, z0 + dv};
            } else {
                verts[0] = new double[]{x0, d, z0};
                verts[1] = new double[]{x0, d, z0 + dv};
                verts[2] = new double[]{x0 + du, d, z0 + dv};
                verts[3] = new double[]{x0 + du, d, z0};
            }
        } else {
            if (positive) {
                verts[0] = new double[]{x0, y0, d + 1};
                verts[1] = new double[]{x0 + du, y0, d + 1};
                verts[2] = new double[]{x0 + du, y0 + dv, d + 1};
                verts[3] = new double[]{x0, y0 + dv, d + 1};
            } else {
                verts[0] = new double[]{x0, y0, d};
                verts[1] = new double[]{x0, y0 + dv, d};
                verts[2] = new double[]{x0 + du, y0 + dv, d};
                verts[3] = new double[]{x0 + du, y0, d};
            }
        }

        double half = CHUNK_SIZE / 2.0;
        for (int vi = 0; vi < 4; vi++) {
            verts[vi][0] -= half;
            verts[vi][1] -= half;
            verts[vi][2] -= half;
        }

        double[][] uvs = new double[][]{{0, 0}, {1, 0}, {1, 1}, {0, 1}};
        BufferedImage tex = fi.texture;
        int[] texPixels = ((DataBufferInt) tex.getRaster().getDataBuffer()).getData();

        Quad quad = new Quad(verts, uvs, texPixels, tex.getWidth(), tex.getHeight(), fi.faceIndex, fi.isTransparent);
        mesh.add(quad);
    }

    // ========== RASTERIZATION ==========

    private void drawQuadPolygonTextured(double[][] pVirtual, Quad q) {
        double[] vx = new double[4];
        double[] vy = new double[4];
        for (int i = 0; i < 4; i++) {
            vx[i] = pVirtual[i][0] / pixelScale;
            vy[i] = pVirtual[i][1] / pixelScale;
        }

        double minX = Math.min(Math.min(vx[0], vx[1]), Math.min(vx[2], vx[3]));
        double maxX = Math.max(Math.max(vx[0], vx[1]), Math.max(vx[2], vx[3]));
        double minY = Math.min(Math.min(vy[0], vy[1]), Math.min(vy[2], vy[3]));
        double maxY = Math.max(Math.max(vy[0], vy[1]), Math.max(vy[2], vy[3]));

        int startX = Math.max(0, (int)Math.floor(minX));
        int endX = Math.min(smallW - 1, (int)Math.ceil(maxX));
        int startY = Math.max(0, (int)Math.floor(minY));
        int endY = Math.min(smallH - 1, (int)Math.ceil(maxY));

        double depth = (pVirtual[0][2] + pVirtual[1][2] + pVirtual[2][2] + pVirtual[3][2]) * 0.25;

        double[] u0 = q.uvs[0], u1 = q.uvs[1], u2 = q.uvs[2], u3 = q.uvs[3];

        for (int py = startY; py <= endY; py++) {
            for (int px = startX; px <= endX; px++) {
                double sampleX = px + 0.5;
                double sampleY = py + 0.5;

                if (!isPointInQuad(sampleX, sampleY, vx, vy)) continue;
                int idx = py * smallW + px;

                if (depth >= zBufInv[idx]) continue;

                double[] bary;
                double texU, texV;

                if (pointInTriangle(sampleX, sampleY, vx[0], vy[0], vx[1], vy[1], vx[2], vy[2])) {
                    bary = barycentric(sampleX, sampleY, vx[0], vy[0], vx[1], vy[1], vx[2], vy[2]);
                    texU = bary[0]*u0[0] + bary[1]*u1[0] + bary[2]*u2[0];
                    texV = bary[0]*u0[1] + bary[1]*u1[1] + bary[2]*u2[1];
                } else {
                    bary = barycentric(sampleX, sampleY, vx[0], vy[0], vx[2], vy[2], vx[3], vy[3]);
                    texU = bary[0]*u0[0] + bary[1]*u2[0] + bary[2]*u3[0];
                    texV = bary[0]*u0[1] + bary[1]*u2[1] + bary[2]*u3[1];
                }

                texU = Math.max(0.0, Math.min(1.0, texU));
                texV = Math.max(0.0, Math.min(1.0, texV));

                int ui = (int) (texU * (q.texW - 1));
                int vi = (int) (texV * (q.texH - 1));
                ui = Math.max(0, Math.min(q.texW - 1, ui));
                vi = Math.max(0, Math.min(q.texH - 1, vi));

                int src = applyFaceShading(q.texPixels[vi * q.texW + ui], q.faceIndex);
                int sa = src >>> 24;
                if (sa == 255) {
                    smallPixels[idx] = src;
                } else if (sa > 0) {
                    int dst = smallPixels[idx];
                    float alpha = sa / 255f;
                    int sr = (src >> 16) & 0xFF, sg = (src >> 8) & 0xFF, sb = src & 0xFF;
                    int dr = (dst >> 16) & 0xFF, dg = (dst >> 8) & 0xFF, db = dst & 0xFF;
                    int rr = Math.min(255, (int) (sr * alpha + dr * (1 - alpha)));
                    int rg = Math.min(255, (int) (sg * alpha + dg * (1 - alpha)));
                    int rb = Math.min(255, (int) (sb * alpha + db * (1 - alpha)));
                    smallPixels[idx] = (0xFF << 24) | (rr << 16) | (rg << 8) | rb;
                }

                zBufInv[idx] = (float) depth;
            }
        }
    }

    private boolean isPointInQuad(double px, double py, double[] x, double[] y) {
        int sign = 0;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            double dx = x[j] - x[i];
            double dy = y[j] - y[i];
            double dpx = px - x[i];
            double dpy = py - y[i];
            double cross = dx * dpy - dy * dpx;
            int s = cross > 0 ? 1 : (cross < 0 ? -1 : 0);
            if (s != 0) {
                if (sign == 0) sign = s;
                else if (sign != s) return false;
            }
        }
        return true;
    }

    private boolean pointInTriangle(double px, double py, double ax, double ay, double bx, double by, double cx, double cy) {
        double v0x = cx - ax, v0y = cy - ay;
        double v1x = bx - ax, v1y = by - ay;
        double v2x = px - ax, v2y = py - ay;

        double dot00 = v0x*v0x + v0y*v0y;
        double dot01 = v0x*v1x + v0y*v1y;
        double dot02 = v0x*v2x + v0y*v2y;
        double dot11 = v1x*v1x + v1y*v1y;
        double dot12 = v1x*v2x + v1y*v2y;

        double denom = dot00 * dot11 - dot01 * dot01;
        if (Math.abs(denom) < 1e-8) return false;
        double invDenom = 1.0 / denom;
        double u = (dot11 * dot02 - dot01 * dot12) * invDenom;
        double v = (dot00 * dot12 - dot01 * dot02) * invDenom;
        return (u >= -1e-6) && (v >= -1e-6) && (u + v <= 1.0 + 1e-6);
    }

    private double[] barycentric(double px, double py, double ax, double ay, double bx, double by, double cx, double cy) {
        double v0x = bx - ax, v0y = by - ay;
        double v1x = cx - ax, v1y = cy - ay;
        double v2x = px - ax, v2y = py - ay;
        double d00 = v0x * v0x + v0y * v0y;
        double d01 = v0x * v1x + v0y * v1y;
        double d11 = v1x * v1x + v1y * v1y;
        double d20 = v2x * v0x + v2y * v0y;
        double d21 = v2x * v1x + v2y * v1y;
        double denom = d00 * d11 - d01 * d01;
        if (Math.abs(denom) < 1e-12) return new double[]{1.0, 0.0, 0.0};
        double v = (d11 * d20 - d01 * d21) / denom;
        double w = (d00 * d21 - d01 * d20) / denom;
        double u = 1.0 - v - w;
        return new double[]{u, v, w};
    }

    private int applyFaceShading(int color, int faceIndex) {
        float brightness = switch(faceIndex) {
            case 0, 1 -> 0.75f;
            case 2 -> 0.6f;
            case 3 -> 1.0f;
            case 4, 5 -> 0.85f;
            default -> 1.0f;
        };

        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;

        r = (int)(r * brightness);
        g = (int)(g * brightness);
        b = (int)(b * brightness);

        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ========== MATRIX HELPERS ==========

    private double[][] perspectiveMatrix(double fovRad, double aspect, double near, double far) {
        double f = 1.0 / Math.tan(fovRad / 2.0);
        double[][] m = new double[4][4];
        m[0][0] = f / aspect;
        m[1][1] = f;
        m[2][2] = (far + near) / (near - far);
        m[2][3] = (2 * far * near) / (near - far);
        m[3][2] = -1;
        m[3][3] = 0;
        return m;
    }

    private double[][] viewMatrix(double camX, double camY, double camZ, double yaw, double pitch) {
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        double cy = Math.cos(yaw), sy = Math.sin(yaw);

        double[][] rot = new double[4][4];
        rot[0][0] = cy;           rot[0][1] = sy*sp;  rot[0][2] = sy*cp;
        rot[1][0] = 0;            rot[1][1] = cp;     rot[1][2] = -sp;
        rot[2][0] = -sy;          rot[2][1] = cy*sp;  rot[2][2] = cy*cp;
        rot[3][3] = 1;

        double[][] trans = identityMatrix();
        trans[0][3] = -camX;
        trans[1][3] = -camY;
        trans[2][3] = -camZ;

        return multiplyMatrices(rot, trans);
    }

    private double[][] rotationYMatrix(double ang) {
        double c = Math.cos(ang);
        double s = Math.sin(ang);
        double[][] m = identityMatrix();
        m[0][0] = c; m[0][2] = s;
        m[2][0] = -s; m[2][2] = c;
        return m;
    }

    private double[][] translateMatrix(double tx, double ty, double tz) {
        double[][] m = identityMatrix();
        m[0][3] = tx;
        m[1][3] = ty;
        m[2][3] = tz;
        return m;
    }

    private double[][] identityMatrix() {
        double[][] m = new double[4][4];
        m[0][0] = 1; m[1][1] = 1; m[2][2] = 1; m[3][3] = 1;
        return m;
    }

    private double[] transformVec4(double[][] m, double[] v) {
        double[] r = new double[4];
        for (int row = 0; row < 4; row++) {
            r[row] = m[row][0]*v[0] + m[row][1]*v[1] + m[row][2]*v[2] + m[row][3]*v[3];
        }
        return r;
    }

    private double[][] multiplyMatrices(double[][] a, double[][] b) {
        double[][] r = new double[4][4];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                double sum = 0;
                for (int k = 0; k < 4; k++) sum += a[i][k] * b[k][j];
                r[i][j] = sum;
            }
        }
        return r;
    }

    private int faceIndexForAxis(int axis, boolean positive) {
        if (axis == 0) return positive ? 4 : 5;
        if (axis == 1) return positive ? 3 : 2;
        return positive ? 1 : 0;
    }

    private boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < CHUNK_SIZE && y < CHUNK_SIZE && z < CHUNK_SIZE;
    }

    private boolean sameFaceInfo(FaceInfo a, FaceInfo b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        return a.faceIndex == b.faceIndex && a.texture == b.texture && a.isTransparent == b.isTransparent;
    }

    // ========== HELPER CLASSES ==========

    private static class FaceInfo {
        int faceIndex;
        BufferedImage texture;
        boolean isTransparent;
        FaceInfo(int faceIndex, BufferedImage texture, boolean isTransparent) {
            this.faceIndex = faceIndex;
            this.texture = texture;
            this.isTransparent = isTransparent;
        }
    }

    private static class Quad {
        final double[][] verts;
        final double[][] uvs;
        final int[] texPixels;
        final int texW, texH;
        final int faceIndex;
        final boolean isTransparent;
        double[][] projected;

        Quad(double[][] verts, double[][] uvs, int[] texPixels, int texW, int texH, int faceIndex, boolean isTransparent) {
            this.verts = verts; this.uvs = uvs;
            this.texPixels = texPixels; this.texW = texW; this.texH = texH;
            this.faceIndex = faceIndex; this.isTransparent = isTransparent;
        }
    }

    private static class QuadInstance {
        final Quad quad; final double[][] projected; final double depth;
        QuadInstance(Quad q, double[][] proj, double depth) {
            this.quad = q;
            this.projected = proj;
            this.depth = depth;
        }
    }
}