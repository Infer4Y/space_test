package xyz.ignite4inferneo.space_test.client;

import xyz.ignite4inferneo.space_test.client.input.KeyBindings;
import xyz.ignite4inferneo.space_test.client.input.KeyInput;
import xyz.ignite4inferneo.space_test.client.input.MouseInput;
import xyz.ignite4inferneo.space_test.client.renderer.Renderer;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;

public class Window {
    private JFrame displayWindow;
    private Renderer renderer = new Renderer();
    private java.util.Queue<Integer> fpsHistory = new LinkedList<>();
    private int historySize = 100;
    private AtomicInteger fpsEstimater = new AtomicInteger();
    private long lastUpdateTime = System.currentTimeMillis();
    private long lastFrameTime = System.nanoTime();

    public Window() {
        displayWindow = new JFrame("Space Test - Voxel Renderer");
        displayWindow.setSize(ClientSettings.windowSize);
        displayWindow.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        displayWindow.setVisible(true);
        displayWindow.createBufferStrategy(3);
        displayWindow.setFocusable(true);
        displayWindow.requestFocus();

        // Initialize mouse input
        MouseInput.init(displayWindow);

        // Start with mouse locked for FPS controls
        MouseInput.setMouseLocked(true);

        renderer.setCanvasSize(displayWindow.getSize());

        Timer renderTimer = new Timer(0, e -> {
            // Calculate delta time
            long now = System.nanoTime();
            double deltaTime = (now - lastFrameTime) / 1_000_000_000.0;
            lastFrameTime = now;

            // Handle input
            handleInput(deltaTime);

            renderer.setCanvasSize(displayWindow.getSize());

            BufferStrategy bufferStrategy = displayWindow.getBufferStrategy();
            if (bufferStrategy == null) return;

            Graphics2D graphics = (Graphics2D) bufferStrategy.getDrawGraphics();
            if (graphics == null) return;

            long currentTime = System.currentTimeMillis();
            if (currentTime - lastUpdateTime >= 1000) {
                updateAverageFPS();
                lastUpdateTime = currentTime;
            }

            graphics.setColor(Color.BLACK);
            graphics.fillRect(0, 0, displayWindow.getWidth(), displayWindow.getHeight());

            if (renderer != null) {
                renderer.render(deltaTime);
                graphics.drawImage(renderer.getScreenBuffer(), 0, 0, null);
            }

            // Draw UI
            if (ClientSettings.showFPS) {
                graphics.setColor(Color.WHITE);
                graphics.drawString("FPS: " + String.format("%.1f", getAverageFPS()), 10, 20);

                String mouseLockStatus = MouseInput.isMouseLocked() ? "LOCKED" : "UNLOCKED";
                graphics.drawString("Mouse: " + mouseLockStatus + " (ESC to toggle)", 10, 40);
                graphics.drawString("Pixel Scale: (+/- to change)", 10, 60);
                graphics.drawString("WASD: Move | Mouse: Look | Q/Shift: Up/Down | G: Toggle Greedy Mesh", 10, 80);
            }

            graphics.dispose();
            bufferStrategy.show();

            fpsEstimater.incrementAndGet();

            // Clear one-frame input states
            KeyInput.endFrame();
            MouseInput.endFrame();
        });

        renderTimer.start();
    }

    private void handleInput(double deltaTime) {
        double moveSpeed = ClientSettings.MOVE_SPEED;

        // Toggle mouse lock (ESC key)
        if (KeyBindings.TOGGLE_MOUSE_LOCK.isPressed()) {
            MouseInput.setMouseLocked(!MouseInput.isMouseLocked());
        }

        // Pixel scale controls
        if (KeyBindings.INCREASE_PIXEL_SCALE.isPressed()) {
            int newScale = Math.min(ClientSettings.MAX_PIXEL_SCALE, renderer.getChunkRenderer().getPixelScale() + 1);
            renderer.getChunkRenderer().setPixelScale(newScale);
            System.out.println("Pixel scale: " + newScale);
        }
        if (KeyBindings.DECREASE_PIXEL_SCALE.isPressed()) {
            int newScale = Math.max(ClientSettings.MIN_PIXEL_SCALE, renderer.getChunkRenderer().getPixelScale() - 1);
            renderer.getChunkRenderer().setPixelScale(newScale);
            System.out.println("Pixel scale: " + newScale);
        }

        // Movement (WASD + Q/Shift)
        double forward = 0, right = 0, up = 0;

        if (KeyBindings.MOVE_FORWARD.isDown()) forward += moveSpeed;
        if (KeyBindings.MOVE_BACK.isDown()) forward -= moveSpeed;
        if (KeyBindings.MOVE_RIGHT.isDown()) right += moveSpeed;
        if (KeyBindings.MOVE_LEFT.isDown()) right -= moveSpeed;
        if (KeyBindings.MOVE_UP.isDown()) up += moveSpeed;
        if (KeyBindings.MOVE_DOWN.isDown()) up -= moveSpeed;

        if (forward != 0 || right != 0 || up != 0) {
            renderer.getChunkRenderer().moveCamera(forward, right, up);
        }

        // Camera rotation - MOUSE (primary) or Arrow keys (backup)
        double yaw = 0, pitch = 0;
        double mouseSensitivity = ClientSettings.MOUSE_SENSITIVITY;
        double lookSpeed = ClientSettings.LOOK_SPEED;

        if (MouseInput.isMouseLocked()) {
            // Use mouse for camera control
            int dx = MouseInput.getMouseDX();
            int dy = MouseInput.getMouseDY();

            if (dx != 0 || dy != 0) {
                yaw = dx * mouseSensitivity;
                pitch = dy * mouseSensitivity;
            }
        } else {
            // Use arrow keys as backup
            if (KeyBindings.LOOK_LEFT.isDown()) yaw -= lookSpeed;
            if (KeyBindings.LOOK_RIGHT.isDown()) yaw += lookSpeed;
            if (KeyBindings.LOOK_UP.isDown()) pitch -= lookSpeed;
            if (KeyBindings.LOOK_DOWN.isDown()) pitch += lookSpeed;
        }

        if (yaw != 0 || pitch != 0) {
            renderer.getChunkRenderer().rotateCamera(yaw, pitch);
        }

        // Toggle greedy meshing (G key)
        if (KeyBindings.TOGGLE_GREEDY_MESHING.isPressed()) {
            boolean current = renderer.getChunkRenderer().isUsingGreedyMeshing();
            renderer.getChunkRenderer().setGreedyMeshing(!current);
            System.out.println("Greedy meshing: " + !current);
        }
    }

    private void updateAverageFPS() {
        int currentFPS = fpsEstimater.getAndSet(0);
        fpsHistory.add(currentFPS);
        if (fpsHistory.size() > historySize) {
            fpsHistory.poll();
        }
    }

    private double getAverageFPS() {
        return fpsHistory.stream().mapToInt(i -> i).average().orElse(0);
    }

    public JFrame getDisplayWindow() {
        return displayWindow;
    }
}