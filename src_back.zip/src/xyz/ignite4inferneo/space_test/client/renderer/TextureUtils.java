package xyz.ignite4inferneo.space_test.client.renderer;

import java.awt.image.BufferedImage;
import java.util.Random;

public class TextureUtils {

    private static final Random rand = new Random();

    public static BufferedImage createRandomNoise(int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int rgb = ((int)(Math.random()*256) << 16) |
                        ((int)(Math.random()*256) << 8) |
                        ((int)(Math.random()*256));
                img.setRGB(x, y, 0xFF000000 | rgb); // Add full alpha
            }
        return img;
    }

    public static BufferedImage createBlockTexture(String type, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                // Bigger, bolder patterns that show up when pixelated
                boolean isEdge = (x % size == 0) || (y % size == 0) || (x == size-1) || (y == size-1);
                boolean isBigDot = ((x / (size >> 1)) % 2 == 0) && ((y / (size >> 1)) % 2 == 0);

                int color = switch(type.toLowerCase()) {
                    case "grass" -> {
                        int baseR = 25;
                        int baseG = 50;
                        int baseB = 160;

                        // Add strong variation
                        int r = baseR + rand.nextInt(40);
                        int g = baseG + rand.nextInt(50);
                        int b = baseB + rand.nextInt(72);

                        // Bold checkerboard pattern
                        if (isBigDot) {
                            r = Math.min(255, r + 40);
                            g = Math.min(255, g + 50);
                            b = Math.min(255, b + 25);
                        }

                        // Strong edges for definition
                        if (isEdge) {
                            r = Math.max(0, r - 30);
                            g = Math.max(0, g - 40);
                            b = Math.max(0, b - 50);
                        }

                        yield (r << 16) | (g << 8) | b;
                    }
                    case "dirt" -> {
                        int r = 90 + rand.nextInt(40);
                        int g = 60 + rand.nextInt(30);
                        int b = 30 + rand.nextInt(20);

                        if (isBigDot) {
                            r = Math.min(255, r + 30);
                            g = Math.min(255, g + 20);
                        }

                        if (isEdge) {
                            r = Math.max(0, r - 25);
                            g = Math.max(0, g - 20);
                            b = Math.max(0, b - 15);
                        }
                        yield (r << 16) | (g << 8) | b;
                    }
                    case "stone" -> {
                        int gray = 90 + rand.nextInt(50);

                        // Bright mineral specks
                        if (isBigDot && rand.nextFloat() < 0.4f) {
                            gray = Math.min(255, gray + 60);
                        }

                        if (isEdge) {
                            gray = Math.max(0, gray - 30);
                        }

                        yield (gray << 16) | (gray << 8) | gray;
                    }
                    default -> 0xFFFFFF;
                };
                img.setRGB(x, y, 0xFF000000 | color);
            }
        }
        return img;
    }
}