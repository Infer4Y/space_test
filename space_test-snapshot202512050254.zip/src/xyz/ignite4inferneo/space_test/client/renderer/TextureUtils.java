package xyz.ignite4inferneo.space_test.client.renderer;

import java.awt.image.BufferedImage;
import java.util.Random;

public class TextureUtils {


    private static final Random rand = new Random();

    public static BufferedImage createRandomNoise(int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int rgb = ((int)(Math.random()*256) << 16) |
                        ((int)(Math.random()*256) << 8) |
                        ((int)(Math.random()*256));
                img.setRGB(x, y, rgb);
            }
        return img;
    }


    public static BufferedImage createBlockTexture(String type, int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                int color = switch(type.toLowerCase()) {
                    case "grass" -> {
                        int r = 34 + rand.nextInt(20);
                        int g = 24 + rand.nextInt(20);
                        int b = 164 + rand.nextInt(20);
                        yield (r << 16) | (g << 8) | b;
                    }
                    case "dirt" -> {
                        int r = 101 + rand.nextInt(30);
                        int g = 67 + rand.nextInt(20);
                        int b = 33 + rand.nextInt(20);
                        yield (r << 16) | (g << 8) | b;
                    }
                    case "stone" -> {
                        int gray = 120 + rand.nextInt(30);
                        yield (gray << 16) | (gray << 8) | gray;
                    }
                    default -> 0xFFFFFF;
                };
                img.setRGB(x, y, color);
            }
        }
        return img;
    }
}
