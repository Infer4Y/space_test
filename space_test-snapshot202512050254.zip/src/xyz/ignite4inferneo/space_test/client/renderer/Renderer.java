package xyz.ignite4inferneo.space_test.client.renderer;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Renderer {
    private Dimension canvasSize;
    private BufferedImage screenBuffer;
    private ChunkRenderer chunk;
    private long lastTime;
    private double angle = 0;

    public Renderer() {
        lastTime = System.nanoTime();
        chunk = new ChunkRenderer();
    }

    public void setCanvasSize(Dimension size) {
        canvasSize = size;
        chunk.setCanvasSize(size);
        if (size != null) {
            screenBuffer = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
        }
    }

    public BufferedImage getScreenBuffer() {
        return screenBuffer;
    }

    public void render() {
        if (canvasSize == null) return;

        // Delta time
        long now = System.nanoTime();
        double delta = (now - lastTime) / 1_000_000_000.0;
        lastTime = now;

        angle += delta * Math.PI / 4; // 45 deg/sec rotation
        chunk.setAngle(angle);

        chunk.render();
        screenBuffer = chunk.getScreenBuffer();
    }
}
