package xyz.ignite4inferneo.space_test.client.renderer;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.*;
import java.util.List;

/**
 * Smooth ChunkRenderer (polygon bounds version):
 *  - Greedy meshing
 *  - Render to downsampled int[] buffer and upscale to screen BufferedImage
 *  - Polygon-based rasterizer with perspective-correct UVs (smooth faces)
 */
public class ChunkRenderer {
    private static final boolean USE_TRANSPARENCY = true;
    private static final int CHUNK_SIZE = 16;
    private final Cube[][][] blocks = new Cube[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE];

    private Dimension canvasSize;
    private BufferedImage screenBuffer;
    private BufferedImage smallBuffer;
    private int[] smallPixels;
    private float[] zBufInv;
    private int smallW, smallH;
    private final int pixelScale;

    private final List<Quad> mesh = new ArrayList<>();
    private boolean dirty = true;

    private long lastTime;
    private double angle = 0;
    private final Random rand = new Random();

    private final BufferedImage[] globalFaceTextures = new BufferedImage[6];

    public ChunkRenderer(int pixelScale) {
        this.pixelScale = Math.max(1, pixelScale);
        this.lastTime = System.nanoTime();

        for (int x = 0; x < CHUNK_SIZE; x++)
            for (int y = 0; y < CHUNK_SIZE; y++)
                for (int z = 0; z < CHUNK_SIZE; z++)
                    if (rand.nextFloat() < 0.12f) blocks[x][y][z] = new Cube();
                    else blocks[x][y][z] = null;

        for (int i = 0; i < 6; i++)
            globalFaceTextures[i] = TextureUtils.createBlockTexture("grass", 64);

        dirty = true;
    }

    public ChunkRenderer() { this(8); }

    public void setCanvasSize(Dimension size) {
        canvasSize = size;
        if (size == null) return;
        screenBuffer = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);

        smallW = Math.max(1, size.width / pixelScale);
        smallH = Math.max(1, size.height / pixelScale);
        smallBuffer = new BufferedImage(smallW, smallH, BufferedImage.TYPE_INT_ARGB);
        smallPixels = ((DataBufferInt) smallBuffer.getRaster().getDataBuffer()).getData();
        zBufInv = new float[smallW * smallH];

        dirty = true;
    }

    public BufferedImage getScreenBuffer() { return screenBuffer; }
    public void setAngle(double angle) { this.angle = angle; }
    public void markDirty() { dirty = true; }

    public void render() {
        if (canvasSize == null || screenBuffer == null) return;

        long now = System.nanoTime();
        double delta = (now - lastTime) / 1_000_000_000.0;
        lastTime = now;
        angle += delta * Math.PI / 8.0;

        buildMeshIfNeeded();

        Arrays.fill(smallPixels, 0xFF000000);
        Arrays.fill(zBufInv, 0f);

        final double s = Math.sin(angle);
        final double c = Math.cos(angle);

        List<QuadInstance> transparentQuads = USE_TRANSPARENCY ? new ArrayList<>() : null;

        for (Quad q : mesh) {
            double[][] proj = q.projected;
            if (proj == null) { q.projected = new double[4][3]; proj = q.projected; }

            for (int i = 0; i < 4; i++) {
                double vx = q.verts[i][0], vy = q.verts[i][1], vz = q.verts[i][2];
                double rx = vx * c - vz * s;
                double rz = vx * s + vz * c;
                double ry = vy;
                rz += 12.0;
                if (rz < 0.001) rz = 0.001;
                double f = 100.0 / rz;
                proj[i][0] = rx * f + smallW * 0.5;
                proj[i][1] = -ry * f + smallH * 0.5;
                proj[i][2] = rz;
            }

            if (q.isTransparent) {
                if (USE_TRANSPARENCY) {
                    double depth = (proj[0][2] + proj[1][2] + proj[2][2] + proj[3][2]) * 0.25;
                    transparentQuads.add(new QuadInstance(q, proj, depth));
                }
            } else {
                drawQuadPolygonTextured(proj, q);
            }
        }

        if (USE_TRANSPARENCY && !transparentQuads.isEmpty()) {
            transparentQuads.sort((a, b) -> Double.compare(b.depth, a.depth));
            for (QuadInstance qi : transparentQuads)
                drawQuadPolygonTextured(qi.projected, qi.quad);
        }

        int screenW = screenBuffer.getWidth();
        int screenH = screenBuffer.getHeight();
        int[] bigPixels = ((DataBufferInt) screenBuffer.getRaster().getDataBuffer()).getData();
        for (int sy = 0; sy < screenH; sy++) {
            int smallY = Math.min(smallH - 1, sy / pixelScale);
            int rowSmall = smallY * smallW;
            int rowBig = sy * screenW;
            for (int sx = 0; sx < screenW; sx++) {
                int smallX = Math.min(smallW - 1, sx / pixelScale);
                bigPixels[rowBig + sx] = smallPixels[rowSmall + smallX];
            }
        }
    }

    private void buildMeshIfNeeded() {
        if (!dirty) return;
        mesh.clear();
        greedyAxis(0);
        greedyAxis(1);
        greedyAxis(2);
        dirty = false;
    }

    private void greedyAxis(int axis) {
        int u = (axis + 1) % 3;
        int v = (axis + 2) % 3;
        int[] dims = {CHUNK_SIZE, CHUNK_SIZE, CHUNK_SIZE};

        for (int d = 0; d < dims[axis]; d++) {
            FaceInfo[][] mask = new FaceInfo[dims[u]][dims[v]];
            for (int i = 0; i < dims[u]; i++) {
                for (int j = 0; j < dims[v]; j++) {
                    int x = axis == 0 ? d : (u == 0 ? i : j);
                    int y = axis == 1 ? d : (u == 1 ? i : j);
                    int z = axis == 2 ? d : (u == 2 ? i : j);
                    int nx = axis == 0 ? d + 1 : x;
                    int ny = axis == 1 ? d + 1 : y;
                    int nz = axis == 2 ? d + 1 : z;
                    Cube a = inBounds(x, y, z) ? blocks[x][y][z] : null;
                    Cube b = inBounds(nx, ny, nz) ? blocks[nx][ny][nz] : null;

                    if (a != null && b == null) mask[i][j] = new FaceInfo(faceIndexForAxis(axis, true), globalFaceTextures[faceIndexForAxis(axis, true)], false);
                    else if (a == null && b != null) mask[i][j] = new FaceInfo(faceIndexForAxis(axis, false), globalFaceTextures[faceIndexForAxis(axis, false)], false);
                    else mask[i][j] = null;
                }
            }

            boolean[][] used = new boolean[dims[u]][dims[v]];
            for (int i = 0; i < dims[u]; i++) {
                for (int j = 0; j < dims[v]; j++) {
                    if (used[i][j]) continue;
                    FaceInfo fi = mask[i][j];
                    if (fi == null) continue;

                    int w = 1;
                    while (i + w < dims[u] && !used[i + w][j] && sameFaceInfo(fi, mask[i + w][j])) w++;
                    int h = 1;
                    outer:
                    while (j + h < dims[v]) {
                        for (int k = 0; k < w; k++)
                            if (used[i + k][j + h] || !sameFaceInfo(fi, mask[i + k][j + h])) break outer;
                        h++;
                    }

                    for (int a0 = 0; a0 < w; a0++)
                        for (int b0 = 0; b0 < h; b0++)
                            used[i + a0][j + b0] = true;

                    double x0 = 0, y0 = 0, z0 = 0;
                    if (axis == 0) { x0 = d; y0 = i; z0 = j; }
                    else if (axis == 1) { x0 = i; y0 = d; z0 = j; }
                    else { x0 = i; y0 = j; z0 = d; }

                    double du = w, dv = h;
                    boolean positive = mask[i][j].faceIndex == faceIndexForAxis(axis, true);

                    double[][] verts = new double[4][3];
                    if (axis == 0) {
                        if (positive) {
                            verts[0] = new double[]{d + 1, y0, z0};
                            verts[1] = new double[]{d + 1, y0 + du, z0};
                            verts[2] = new double[]{d + 1, y0 + du, z0 + dv};
                            verts[3] = new double[]{d + 1, y0, z0 + dv};
                        } else {
                            verts[0] = new double[]{d, y0, z0};
                            verts[1] = new double[]{d, y0, z0 + dv};
                            verts[2] = new double[]{d, y0 + du, z0 + dv};
                            verts[3] = new double[]{d, y0 + du, z0};
                        }
                    } else if (axis == 1) {
                        if (positive) {
                            verts[0] = new double[]{x0, d + 1, z0};
                            verts[1] = new double[]{x0 + du, d + 1, z0};
                            verts[2] = new double[]{x0 + du, d + 1, z0 + dv};
                            verts[3] = new double[]{x0, d + 1, z0 + dv};
                        } else {
                            verts[0] = new double[]{x0, d, z0};
                            verts[1] = new double[]{x0, d, z0 + dv};
                            verts[2] = new double[]{x0 + du, d, z0 + dv};
                            verts[3] = new double[]{x0 + du, d, z0};
                        }
                    } else {
                        if (positive) {
                            verts[0] = new double[]{x0, y0, d + 1};
                            verts[1] = new double[]{x0 + du, y0, d + 1};
                            verts[2] = new double[]{x0 + du, y0 + dv, d + 1};
                            verts[3] = new double[]{x0, y0 + dv, d + 1};
                        } else {
                            verts[0] = new double[]{x0, y0, d};
                            verts[1] = new double[]{x0, y0 + dv, d};
                            verts[2] = new double[]{x0 + du, y0 + dv, d};
                            verts[3] = new double[]{x0 + du, y0, d};
                        }
                    }

                    double half = CHUNK_SIZE / 2.0;
                    for (int vi = 0; vi < 4; vi++) {
                        verts[vi][0] -= half; verts[vi][1] -= half; verts[vi][2] -= half;
                    }

                    double[][] uvs = new double[][]{{0, 0}, {1, 0}, {1, 1}, {0, 1}};
                    BufferedImage tex = mask[i][j].texture;
                    int[] texPixels = ((DataBufferInt) tex.getRaster().getDataBuffer()).getData();

                    Quad quad = new Quad(verts, uvs, texPixels, tex.getWidth(), tex.getHeight(), mask[i][j].faceIndex, mask[i][j].isTransparent);
                    mesh.add(quad);
                }
            }
        }
    }

    private int faceIndexForAxis(int axis, boolean positive) {
        if (axis == 0) return positive ? 4 : 5;
        if (axis == 1) return positive ? 3 : 2;
        return positive ? 1 : 0;
    }

    private boolean inBounds(int x, int y, int z) {
        return x >= 0 && y >= 0 && z >= 0 && x < CHUNK_SIZE && y < CHUNK_SIZE && z < CHUNK_SIZE;
    }

    private boolean sameFaceInfo(FaceInfo a, FaceInfo b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        return a.faceIndex == b.faceIndex && a.texture == b.texture && a.isTransparent == b.isTransparent;
    }

    /** Polygon-based quad rasterizer (textured, perspective-correct, smooth edges) */
    private void drawQuadPolygonTextured(double[][] p, Quad q) {
        int[] x = new int[]{(int) p[0][0], (int) p[1][0], (int) p[2][0], (int) p[3][0]};
        int[] y = new int[]{(int) p[0][1], (int) p[1][1], (int) p[2][1], (int) p[3][1]};
        double depth = (p[0][2] + p[1][2] + p[2][2] + p[3][2]) * 0.25;
        Polygon poly = new Polygon(x, y, 4);
        Rectangle bounds = poly.getBounds();

        for (int px = bounds.x; px < bounds.x + bounds.width; px++) {
            if (px < 0 || px >= smallW) continue;
            for (int py = bounds.y; py < bounds.y + bounds.height; py++) {
                if (py < 0 || py >= smallH) continue;
                if (poly.contains(px, py)) {
                    int idx = py * smallW + px;
                    if (depth > zBufInv[idx]) {
                        zBufInv[idx] = (float) depth;

                        // Simple bilinear approximation via UV mapping
                        double u = 0, v = 0;
                        // approximate barycentric u,v
                        u = ((px - x[0]) + (px - x[1]) + (px - x[2]) + (px - x[3])) / 4.0;
                        v = ((py - y[0]) + (py - y[1]) + (py - y[2]) + (py - y[3])) / 4.0;
                        int ui = (int) (u * (q.texW - 1));
                        int vi = (int) (v * (q.texH - 1));
                        if (ui < 0) ui = 0; else if (ui >= q.texW) ui = q.texW - 1;
                        if (vi < 0) vi = 0; else if (vi >= q.texH) vi = q.texH - 1;

                        int src = q.texPixels[vi * q.texW + ui];
                        int sa = src >>> 24;
                        if (sa == 255) smallPixels[idx] = src;
                        else if (sa > 0) {
                            int dst = smallPixels[idx];
                            float alpha = sa / 255f;
                            int sr = (src >> 16) & 0xFF, sg = (src >> 8) & 0xFF, sb = src & 0xFF;
                            int dr = (dst >> 16) & 0xFF, dg = (dst >> 8) & 0xFF, db = dst & 0xFF;
                            int rr = Math.min(255, (int) (sr * alpha + dr * (1 - alpha)));
                            int rg = Math.min(255, (int) (sg * alpha + dg * (1 - alpha)));
                            int rb = Math.min(255, (int) (sb * alpha + db * (1 - alpha)));
                            smallPixels[idx] = (0xFF << 24) | (rr << 16) | (rg << 8) | rb;
                        }
                    }
                }
            }
        }
    }

    private static class FaceInfo {
        int faceIndex;
        BufferedImage texture;
        boolean isTransparent;
        FaceInfo(int faceIndex, BufferedImage texture, boolean isTransparent) { this.faceIndex = faceIndex; this.texture = texture; this.isTransparent = isTransparent; }
    }

    private static class Quad {
        final double[][] verts;
        final double[][] uvs;
        final int[] texPixels;
        final int texW, texH;
        final int faceIndex;
        final boolean isTransparent;
        double[][] projected;

        Quad(double[][] verts, double[][] uvs, int[] texPixels, int texW, int texH, int faceIndex, boolean isTransparent) {
            this.verts = verts; this.uvs = uvs;
            this.texPixels = texPixels; this.texW = texW; this.texH = texH;
            this.faceIndex = faceIndex; this.isTransparent = isTransparent;
        }
    }

    private static class QuadInstance {
        final Quad quad; final double[][] projected; final double depth;
        QuadInstance(Quad q, double[][] proj, double depth) { this.quad = q; this.projected = proj; this.depth = depth; }
    }
}
