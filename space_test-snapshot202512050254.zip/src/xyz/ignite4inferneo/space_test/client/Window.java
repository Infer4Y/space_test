package xyz.ignite4inferneo.space_test.client;

import xyz.ignite4inferneo.space_test.client.renderer.Cube;
import xyz.ignite4inferneo.space_test.client.renderer.Renderer;
import xyz.ignite4inferneo.space_test.client.renderer.TextureUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;

public class Window {
    private JFrame displayWindow;
    private Renderer renderer  = new Renderer();
    private java.util.Queue<Integer> fpsHistory = new LinkedList<>();
    private int historySize = 100; // Number of samples to keep for averaging (adjust based on your needs)
    private AtomicInteger fpsEstimater = new AtomicInteger();
    private long lastUpdateTime = System.currentTimeMillis();

    public Window(){
        displayWindow = new JFrame("");

        displayWindow.setSize(ClientSettings.windowSize);

        displayWindow.setVisible(true);

        displayWindow.createBufferStrategy(3);
        displayWindow.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        renderer.setCanvasSize(displayWindow.getSize());

        Timer renderTimer = new Timer(0, e -> {
            renderer.setCanvasSize(displayWindow.getSize());

            BufferStrategy bufferStrategy = displayWindow.getBufferStrategy();

            if (bufferStrategy == null) return;

            Graphics2D graphics = (Graphics2D) bufferStrategy.getDrawGraphics();

            if (graphics == null) return;

            long currentTime = System.currentTimeMillis();
            if (currentTime - lastUpdateTime >= 1000) { // Update FPS every second
                updateAverageFPS();
                lastUpdateTime = currentTime;
            }

            graphics.setColor(Color.BLACK);
            graphics.fillRect(0, 0, displayWindow.getWidth(), displayWindow.getHeight());

            // Put render hook here
            if (renderer != null) {
                renderer.render(); // clears and draws background + GUI
                graphics.drawImage(renderer.getScreenBuffer(), 0, 0, null);
            }



            if (ClientSettings.showFPS) {
                graphics.setColor(Color.WHITE);
                graphics.drawString("FPS : " + getAverageFPS(), 10, 50);
            }

            graphics.dispose();
            bufferStrategy.show();

            fpsEstimater.incrementAndGet();
        });

        renderTimer.start();
    }


    private void updateAverageFPS() {
        int currentFPS = fpsEstimater.getAndSet(0);
        fpsHistory.add(currentFPS);
        if (fpsHistory.size() > historySize) {
            fpsHistory.poll();
        }
    }

    private double getAverageFPS() {
        return fpsHistory.stream().mapToInt(i -> i).average().orElse(0);
    }

    public JFrame getDisplayWindow() {
        return displayWindow;
    }
}
