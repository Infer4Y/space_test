package xyz.ignite4inferneo.space_test.client.input;

import xyz.ignite4inferneo.space_test.client.ClientSettings;

public class KeyBindings {

    public static KeyBinding MOVE_FORWARD;
    public static KeyBinding MOVE_BACK;
    public static KeyBinding MOVE_LEFT;
    public static KeyBinding MOVE_RIGHT;
    public static KeyBinding JUMP;
    public static KeyBinding INVENTORY;

    public static void init() {
        MOVE_FORWARD = new KeyBinding("forward", ClientSettings.KEY_FORWARD);
        MOVE_BACK = new KeyBinding("back", ClientSettings.KEY_BACK);
        MOVE_LEFT = new KeyBinding("left", ClientSettings.KEY_LEFT);
        MOVE_RIGHT = new KeyBinding("right", ClientSettings.KEY_RIGHT);
        JUMP = new KeyBinding("jump", ClientSettings.KEY_JUMP);
        INVENTORY = new KeyBinding("inventory", ClientSettings.KEY_INVENTORY);
    }
}

