package xyz.ignite4inferneo.space_test;

import xyz.ignite4inferneo.space_test.client.Window;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        new Window();
    }
}